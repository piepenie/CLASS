package com.example.app.filter.type;

public enum Role {
	ROLE_USER,			// 0
	ROLE_BUSINESSMAN,		// 1
	ROLE_ADMIN			// 2
}
